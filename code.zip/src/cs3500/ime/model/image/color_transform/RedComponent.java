package cs3500.ime.model.image.color_transform;

public final class RedComponent extends AColorTransform {

  public RedComponent() {
    super(new double[][]{{1, 0, 0}, {1, 0, 0}, {1, 0, 0}});
  }
}
