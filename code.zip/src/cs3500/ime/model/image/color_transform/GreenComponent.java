package cs3500.ime.model.image.color_transform;

public final class GreenComponent extends AColorTransform {

  public GreenComponent() {
    super(new double[][]{{0, 1, 0}, {0, 1, 0}, {0, 1, 0}});
  }
}
